# ChubbyTabby
Chrome Custom Tabs
This is a sample project using the Chrome custom tabs feature to show how we can use it and customize look and feel. 

