The code bundle includes code files for Chapter 1, 3, 5, 7, and 8

Chapter 2, 4, and 6 does not have code files