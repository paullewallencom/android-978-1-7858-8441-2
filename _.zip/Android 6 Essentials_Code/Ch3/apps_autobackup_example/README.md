
Android Automatic Backup Sample
===================================

Sample demonstrating Android Marshmallow apps auto backup feature.


Api requirements
--------------

- Android SDK v23
- Android Build Tools v23.0.1
- Android Support Repository
